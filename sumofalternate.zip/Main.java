import java.util.Scanner;
public class Main {

static int ar[]; static int sum = 0; static double avg = 0.0;
static Scanner sc = new Scanner(System.in);
public Main(int s){
    ar = new int[s];
}
void accept(){
    for (int i = 0; i<ar.length; i++){
        System.out.println("Enter value of ar["+i+"] : ");
        ar[i] = sc.nextInt();
    }
}
void calc(int pos){
    for (int i = (pos-1); i<ar.length; i+=2){
        sum = ar[i] + ar[i+1];
    }
}
public static void main(String[] args){
    boolean run = true;
    while (run){
    System.out.println("Enter the size of the array: ");
    int size = sc.nextInt(); 
    Main a = new Main(size);
    a.accept(); 
    System.out.println("Enter starting position: "); int pos = sc.nextInt();
    if (pos<0 || pos>ar.length){
        System.out.println("ERROR: Restart operations");
        run = true;
    }
    a.calc(pos); 
    run = false; avg = sum/ar.length;
    System.out.println("The sum of alternate elements is: " + sum + "\n and their average is: " + avg); 
    System.out.println("Dhruv Chawla 22CSU298");

   }
 }
}

