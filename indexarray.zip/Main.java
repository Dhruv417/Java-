public class Main{
  public static void main(String[] args) {
    int[] numbers = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    int target = 80;
    int index = -1;
    
    for (int i = 0; i < numbers.length; i++) {
      if (numbers[i] == target) {
        index = i;
        break;
      }
    }
    if (index != -1) {
      System.out.println("Array: " + Arrays.toString(numbers));
      System.out.println("Target value: " + target);
      System.out.println("Index of target value: " + index);
    } 
    else {
      System.out.println("Target value not found in the array.");
      System.out.println("Dhruv Chawla 22CSU298");
    }
  }
}
