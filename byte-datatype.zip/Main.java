public class Main {
    public static void main(String[] args){
        byte myNum = 127;
        System.out.println(myNum);
        byte myNum1 = -129;
        System.out.println(myNum1);
        byte myNum2 = 200;
        System.out.println(myNum2);
    }
}